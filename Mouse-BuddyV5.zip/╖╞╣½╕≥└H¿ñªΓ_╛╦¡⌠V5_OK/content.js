// content.js - 最終穩固版：徹底簡化百次動畫，確保尺寸正確

// --- 全域變數宣告 ---
let img = null;
let mode = 'home'; // 預設為顧家模式，此處應與 popup.js 的預設值同步
const builtinPaths = [
    'images/chiikawa_001.gif',
    'images/hachiware_001.gif',
    'images/usagi_001.gif',
    'images/Kanahei.gif',
    'images/maltese.gif',
    'images/maltese2.gif',
    'images/snoopy.gif',
    'images/hellokitty.gif'
];

let targetX = 0, targetY = 0; // 用於 'follow' 模式 (滑鼠目標點)
let currentX = 0, currentY = 0; // 用於 'follow' 模式 (角色當前渲染點)
let currentFollowDistance = 35; // 跟隨模式的當前距離，預設 35px

let isHidden = false;  // 用來追蹤角色顯示狀態
let mouseMoveListener = null;  // 定義 mouseMoveListener 變數
let followAnimationFrameId = null;

// 遊玩模式相關的全域變數
let playModeInterval = null;
let isBouncing = false; // 用於遊玩模式的活潑動作
// [新增] 判斷是否正在逃跑
let isEscaping = false; // Add this new variable

// 顧家/跟隨模式彈跳相關變數
let stationaryBounceTimer = null;
let stationaryBounceInterval = null;
let isStationaryBouncing = false; // 避免同時觸發多次靜止彈跳 (顧家/跟隨)

let originalDisplayState = 'block'; // 儲存角色原始的 display 狀態，用於列印後恢復

let isClickAnimating = false; // 判斷是否正在執行由點擊觸發的動畫 (如短暫彈跳)
let imgClickListener = null; // 用於跟隨和遊玩模式的點擊監聽器

let clickCount = 0; // 點擊計數器
const CLICK_COUNT_STORAGE_KEY = 'characterClickCount'; // 儲存計數的 key

let lastEncouragementTriggerCount = 0; 

let originalImgWidth = 64; // 初始化為預設值，之後會被精確更新為使用者設定的寬度

// 顧家模式下累計放大相關變數
let currentAccumulatedScale = 1.0; // 當前累計放大比例 (1.0 = 原始大小)
let currentScaleLevel = 0; // 當前累計放大級別 (0-MAX_ACCUMULATED_LEVELs)
let resetAccumulatedScaleTimer = null; // 用於自動縮回的計時器
const SCALE_PER_CLICK = 0.05; // 每次點擊放大 5%
const SCALE_RESET_IDLE_TIME = 1000; // 1秒不點擊後自動縮回 (顧家模式)

// 常量定義
const FOLLOW_TRANSITION_DURATION = 0.1; // 跟隨模式移動動畫時間 (秒)
const STATIONARY_BOUNCE_DURATION = 150; // 靜止彈跳動畫每一步的時間 (毫秒)
const CLICK_BOUNCE_DURATION = 200; // 點擊彈跳動畫每一步的時間 (毫秒)
const PLAY_MODE_INTERVAL_MIN = 2000; // 遊玩模式最小間隔 (毫秒)
const PLAY_MODE_INTERVAL_MAX = 4000; // 遊玩模式最大間隔 (毫秒)
const PLAY_MODE_ACTION_CHANCE = 0.3; // 遊玩模式觸發特殊動作的機率
const TEASING_MESSAGE_FADE_DURATION = 1000; // 遊玩模式挑釁話語淡出時間 (毫秒)
const HUNDRED_CLICK_MESSAGE_FADE_DURATION = 4000; // 百次點擊提示淡出時間 (毫秒)
const PLUS_N_MESSAGE_FADE_DURATION = 800; // +N 數字提示淡出時間 (毫秒)
const PLAY_MODE_ESCAPE_DURATION = 300; // [新增] 遊玩模式逃跑動畫時間 (毫秒)


// 提醒訊息列表 (顧家模式滿百觸發)
const reminderMessages = [
    "你是不是很閒？", "趕快去工作！", "老闆在看喔！", "小心有人在看你！", "別再點了啦！",
    "這是上班時間！", "我覺得你的滑鼠快壞了！", "摸魚被發現囉！", "你手會痠嗎！", "該動一下囉！"
];

// 遊玩模式挑釁話語列表
const teasingMessages = [
    "來抓我啊！", "抓不到～", "哼！就是抓不到！", "你差一點點！", "再快一點啦！",
    "再給你一次機會!", "還沒結束呢！", "哇哈哈！", "有本事再來啊！", "別放棄喔！"
];

// 顧家模式拖曳相關變數
let isDragging = false;
let dragOffsetX = 0;
let dragOffsetY = 0;
let lastMouseDownX = 0;
let lastMouseDownY = 0;
const DRAG_THRESHOLD = 5; // 判斷是拖曳還是點擊的門檻 (像素)
const HOME_POSITION_STORAGE_KEY = 'homeModePosition'; // 儲存顧家模式位置的 key

// --- 確保創建角色圖片 ---
function ensureFollowerImg() {
    if (!img) {
        img = document.createElement('img');
        img.id = 'mouse-follow-img';
        img.classList.add('mouse-follow-img');
        img.style.position = 'fixed';
        img.style.pointerEvents = 'none'; // 預設不阻擋滑鼠事件 (只有點擊模式下需要改變)
        img.style.zIndex = '999999';
        img.style.width = '0px'; 
        img.style.height = 'auto';

        img.style.display = 'none';
        img.style.opacity = '0';
        img.style.left = '-1000px';

        // 嘗試將圖片添加到 body，如果 body 不存在則等待
        if (document.body) {
            document.body.appendChild(img);
            // console.log('角色圖片元素已創建並添加到 DOM.'); // 優化：移除頻繁日誌
        } else {
            // 如果 body 不存在，則在 DOMContentLoaded 後嘗試添加
            document.addEventListener('DOMContentLoaded', () => {
                if (!document.body.contains(img)) { // 再次檢查，避免重複添加
                    document.body.appendChild(img);
                    // console.log('角色圖片元素在 DOMContentLoaded 後添加到 DOM.'); // 優化：移除頻繁日誌
                }
            }, { once: true }); // 只監聽一次
        }
        
        img.onload = () => {
            // 這個 onload 只是為了確保圖片載入完成，不在此處設定 originalImgWidth
        };
        img.onerror = () => {
            console.error('圖片載入失敗！恢復為預設圖片。'); // 優化：保留錯誤日誌
            img.src = chrome.runtime.getURL('images/chiikawa_001.gif');
        };
    } else {
        // 確保元素仍然在 body 中，如果被移除則重新添加
        if (!document.body.contains(img)) {
            if (document.body) {
                 document.body.appendChild(img);
                 // console.log('角色圖片元素已重新添加到 DOM (因被移除而恢復).'); // 優化：移除頻繁日誌
            } else {
                 document.addEventListener('DOMContentLoaded', () => {
                    if (!document.body.contains(img)) { // 再次檢查，避免重複添加
                        document.body.appendChild(img);
                        // console.log('角色圖片元素在 DOMContentLoaded 後重新添加到 DOM.'); // 優化：移除頻繁日誌
                    }
                }, { once: true }); // 只監聽一次
            }
        }
    }
}

// --- 更新角色圖片與設定 (通用設定更新函數) ---
function updateCharacterSettings(identifier, width, followDistance, initialHiddenState, receivedClickCount, callback = null) {
    ensureFollowerImg(); // 確保 img 元素存在

    if (!img) {
        console.warn("角色圖片元素尚未準備好，無法更新設定。"); // 優化：保留警告日誌
        if (callback) callback();
        return;
    }

    if (typeof followDistance === 'number') {
        currentFollowDistance = followDistance;
        // console.log(`跟隨距離更新為: ${currentFollowDistance}px`); // 優化：移除頻繁日誌
    }

    if (typeof initialHiddenState === 'boolean') {
        isHidden = initialHiddenState;
    }

    originalImgWidth = width; 
    img.style.width = width + 'px'; 
    img.style.height = 'auto'; 
    // console.log(`圖片設定為: ${identifier}, 寬度: ${width}px`); // 優化：移除頻繁日誌

    const performCallback = () => {
        if (callback) callback();
    };

    let srcToLoad;
    if (identifier === 'custom') {
        chrome.storage.local.get('customCharacters', (data) => {
            const customs = data.customCharacters || [];
            srcToLoad = customs.length > 0 ? customs[0].value : chrome.runtime.getURL('images/chiikawa_001.gif');
            if (img.src !== srcToLoad) {
                img.src = srcToLoad;
                img.onload = performCallback;
                img.onerror = () => { handleImageError(); performCallback(); };
            } else {
                performCallback();
            }
        });
    } else {
        const index = parseInt(identifier.replace('builtin-', ''));
        const path = builtinPaths[index] || builtinPaths[0];
        srcToLoad = chrome.runtime.getURL(path);
        if (img.src !== srcToLoad) {
            img.src = srcToLoad;
            img.onload = performCallback;
            img.onerror = () => { handleImageError(); performCallback(); };
        } else {
            performCallback();
        }
    }

    const handleImageError = () => {
        console.error('圖片載入失敗！恢復為預設圖片。'); // 優化：保留錯誤日誌
        img.src = chrome.runtime.getURL('images/chiikawa_001.gif');
    };
}

// --- 彈跳動畫函式 (顧家/跟隨模式共用) ---
function triggerStationaryBounce() {
    if (!img || isStationaryBouncing || isClickAnimating) return; 

    isStationaryBouncing = true;
    img.style.transition = `transform ${STATIONARY_BOUNCE_DURATION / 1000}s ease-out`;

    img.style.transform = 'translateY(-15px)';
    setTimeout(() => {
        img.style.transform = 'translateY(5px)';
        setTimeout(() => {
            img.style.transform = 'translateY(0)';
            setTimeout(() => {
                isStationaryBouncing = false;
                // 恢復模式特定的過渡效果
                if (mode === 'follow') {
                    img.style.transition = `left ${FOLLOW_TRANSITION_DURATION}s ease-out, top ${FOLLOW_TRANSITION_DURATION}s ease-out`;
                } else { // 'home' 和 'play' 模式不需要定位過渡，或有其特殊過渡
                    img.style.transition = 'none'; // 顧家模式不應有定位過渡
                }
            }, STATIONARY_BOUNCE_DURATION);
        }, STATIONARY_BOUNCE_DURATION);
    }, STATIONARY_BOUNCE_DURATION);
}

// --- 點擊角色時的彈跳放大動畫函式 (短暫放大，用於所有模式點擊) ---
function triggerClickBounceAndEnlarge() {
    // 顧家模式不觸發這個動畫，它有自己的累計放大動畫
    if (mode === 'home' || isClickAnimating || isStationaryBouncing) {
        // console.log("當前模式為顧家或有其他動畫進行，跳過通用點擊彈跳放大。"); // 優化：移除頻繁日誌
        return; 
    }

    isClickAnimating = true; 
    img.style.transition = `transform ${CLICK_BOUNCE_DURATION / 1000}s ease-out`;

    const originalScale = 1;
    const enlargedScale = 1.2;
    const bounceHeight = -20;

    img.style.transform = `translateY(${bounceHeight}px) scale(${enlargedScale})`;

    setTimeout(() => {
        img.style.transform = `translateY(${bounceHeight / 2}px) scale(${enlargedScale})`;

        setTimeout(() => {
            img.style.transform = `translateY(0) scale(${originalScale})`;
            
            setTimeout(() => {
                isClickAnimating = false; 
                // 恢復模式特定的過渡效果
                if (mode === 'follow') {
                    img.style.transition = `left ${FOLLOW_TRANSITION_DURATION}s ease-out, top ${FOLLOW_TRANSITION_DURATION}s ease-out`;
                } else if (mode === 'play') { 
                     // 遊玩模式的過渡時間需要與其運動邏輯匹配
                     // [修改] 當角色在逃跑時，不應立即恢復到移動過渡，等待逃跑動畫完成
                     if (!isEscaping) { 
                         img.style.transition = 'left 1.5s ease-out, top 1.5s ease-out, transform 0.6s ease-out, opacity 0.3s ease-in-out';
                     }
                } else {
                    img.style.transition = 'none'; // 預防性重置
                }
            }, CLICK_BOUNCE_DURATION);
        }, CLICK_BOUNCE_DURATION);
    }, CLICK_BOUNCE_DURATION);
}

// --- 顧家模式下，處理累計放大的點擊事件函式 ---
function handleAccumulatedScaleClick() {
    if (isClickAnimating) { // 如果通用點擊動畫正在進行，則跳過
        // console.log("通用點擊動畫正在進行，跳過顧家模式累計放大。"); // 優化：移除頻繁日誌
        return; 
    }

    // 確保靜止彈跳在累計放大時停止
    if (stationaryBounceTimer) {
        clearTimeout(stationaryBounceTimer);
        stationaryBounceTimer = null;
    }
    if (isStationaryBouncing) {
        img.style.transform = 'none'; // 立即重置變換
        isStationaryBouncing = false;
    }
    // 停止顧家模式的靜止彈跳 Interval，避免衝突
    if (stationaryBounceInterval) {
        clearInterval(stationaryBounceInterval);
        stationaryBounceInterval = null;
        // console.log('清除 stationaryBounceInterval (為累計放大暫停)'); // 優化：移除頻繁日誌
    }

    currentScaleLevel++;
    currentAccumulatedScale = 1.0 + (currentScaleLevel * SCALE_PER_CLICK);

    // 點擊時有一個小的上跳動畫
    img.style.transition = 'transform 0.1s linear'; 
    const bounceY = -5; 
    img.style.transform = `translateY(${bounceY}px) scale(${currentAccumulatedScale})`;
    
    setTimeout(() => {
        img.style.transform = `scale(${currentAccumulatedScale})`; // 回落到原位但保持放大
        img.style.transition = 'transform 0.1s linear'; // 恢復短暫過渡以平滑縮放
    }, 100); 

    // console.log(`累計放大：級別 ${currentScaleLevel}, 比例 ${currentAccumulatedScale.toFixed(2)}`); // 優化：移除頻繁日誌

    // 重設自動縮回計時器 (放開滑鼠縮回的邏輯保持)
    if (resetAccumulatedScaleTimer) {
        clearTimeout(resetAccumulatedScaleTimer);
    }
    resetAccumulatedScaleTimer = setTimeout(() => {
        // console.log("閒置超時，觸發縮回。"); // 優化：移除頻繁日誌
        resetAccumulatedScale();
    }, SCALE_RESET_IDLE_TIME);
}

// --- 顧家模式下，將角色縮回原始大小的函式 ---
function resetAccumulatedScale() {
    if (isClickAnimating || (currentAccumulatedScale === 1.0 && currentScaleLevel === 0)) return;

    // console.log("顧家模式：縮回原始大小。"); // 優化：移除頻繁日誌
    currentAccumulatedScale = 1.0; 
    currentScaleLevel = 0; 

    img.style.transition = 'transform 0.3s ease-out'; 
    img.style.transform = 'scale(1.0)'; 

    setTimeout(() => {
        img.style.transition = 'none'; // 縮回動畫完成後，移除過渡
        // console.log("縮回動畫完成，過渡已重置。"); // 優化：移除頻繁日誌
        // 恢復顧家模式的靜止彈跳 Interval
        if (mode === 'home' && !stationaryBounceInterval) { // 只有在顧家模式下才恢復
            stationaryBounceInterval = setInterval(() => {
                triggerStationaryBounce();
            }, Math.random() * 2000 + 3000); 
            // console.log('恢復顧家模式靜止彈跳 Interval'); // 優化：移除頻繁日誌
        }
    }, 300); 
}

// --- 顯示點擊計數動畫函式 (顧家模式 +1 或提示語) ---
// 這裡將根據 isHundredMultiple 和 isTeasingMessage 應用不同的行內樣式
function showClickTextOrMessage(isHundredMultiple = false, message = null, isTeasingMessage = false) {
    // **每次點擊都創建一個新的 div，動畫結束後移除**
    const textElement = document.createElement('div');
    
    // 通用浮動文字樣式 - 直接行內設定
    textElement.style.position = 'fixed';
    textElement.style.fontFamily = `'Segoe UI', 'Microsoft JhengHei', sans-serif`;
    textElement.style.fontWeight = 'bold';
    textElement.style.pointerEvents = 'none'; // 預設不阻擋滑鼠事件 (只有點擊模式下需要改變)
    textElement.style.whiteSpace = 'nowrap'; // 防止文字換行
    textElement.style.willChange = 'opacity, transform'; 
    textElement.style.opacity = '0'; // 預設隱藏
    textElement.style.zIndex = '9999999'; // 確保在角色上方
    textElement.style.textShadow = '1px 1px 3px rgba(0,0,0,0.5), -1px -1px 3px rgba(0,0,0,0.5)'; // 顯著的陰影

    const rect = img.getBoundingClientRect(); // 獲取圖片的當前位置和尺寸
    
    if (isHundredMultiple) { // 顧家模式百次提示：樣式更大、在左側飄動
        textElement.textContent = message;
        textElement.style.fontSize = '38px'; 
        textElement.style.fontWeight = '900'; 
        textElement.style.padding = '30px 60px'; 
        textElement.style.borderRadius = '30px'; 
        textElement.style.boxShadow = '0 15px 35px rgba(0,0,0,0.7)'; 
        textElement.style.backgroundColor = 'rgba(0,0,0,0.95)'; 
        textElement.style.color = 'white'; 
        textElement.style.textShadow = '5px 5px 12px rgba(0,0,0,0.9)'; 
        textElement.style.border = '6px solid'; 
        textElement.style.boxSizing = 'border-box'; 
        textElement.style.whiteSpace = 'nowrap'; 
        textElement.style.display = 'inline-block'; 
        
        const randomColor = `hsl(${Math.random() * 360}, 100%, 70%)`; 
        textElement.style.borderColor = randomColor; 

        // 定位到圖片左側
        const imgCenterX = rect.left + img.offsetWidth / 2;
        const imgCenterY = rect.top + img.offsetHeight / 2;
        const offsetX = img.offsetWidth / 2 + 20; // 圖片一半寬度 + 20px 間距
        
        textElement.style.left = `${imgCenterX - offsetX}px`;
        textElement.style.top = `${imgCenterY - (textElement.offsetHeight / 2)}px`; // 垂直居中於圖片
        textElement.style.transform = `translate(-100%, -50%)`; // 初始位置調整
        
    } else if (isTeasingMessage) { // 遊玩模式挑釁話語：樣式較小，在圖片附近隨機飄動
        textElement.textContent = message;
        // 專為遊玩模式挑釁話語設定的樣式 - 調整大小
        textElement.style.fontSize = '18px'; // 從 48px 調小到 32px，再從 36px 調小
        textElement.style.fontWeight = '800'; 
        textElement.style.padding = '8px 16px'; // 內邊距相應調小
        textElement.style.borderRadius = '8px'; 
        textElement.style.boxShadow = '0 5px 12px rgba(0,0,0,0.5)'; // 陰影相應調小
        textElement.style.backgroundColor = 'rgba(20,20,20,0.9)'; 
        textElement.style.color = 'white'; 
        textElement.style.textShadow = '2px 2px 5px rgba(0,0,0,0.7)'; 
        textElement.style.border = '3px solid'; 
        textElement.style.boxSizing = 'border-box'; 
        textElement.style.whiteSpace = 'nowrap'; 
        textElement.style.display = 'inline-block'; 

        const randomColor = `hsl(${Math.random() * 360}, 100%, 70%)`; 
        textElement.style.borderColor = randomColor; 

        // 定位到圖片中心附近，隨機偏移，並確保在視窗內
        const randomXOffset = Math.random() * 20 - 10; // 左右隨機偏移 -10 到 +10
        const randomYOffset = Math.random() * 20 - 10; // 上下隨機偏移 -10 到 +10
        
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;

        // 需要在 appendChild 後才能獲取正確的 offsetWidth/offsetHeight
        // 這裡直接添加到 body，然後獲取尺寸，再移除，以確保精確度
        document.body.appendChild(textElement); // 暫時添加到 DOM 以獲取尺寸
        const elementWidth = textElement.offsetWidth;
        const elementHeight = textElement.offsetHeight;
        document.body.removeChild(textElement); // 移除，等待實際渲染

        let initialLeft = rect.left + (rect.width / 2) + randomXOffset;
        let initialTop = rect.top + (rect.height / 2) + randomYOffset;

        const minLeft = elementWidth / 2 + 10;
        const maxLeft = viewportWidth - elementWidth / 2 - 10;
        const minTop = elementHeight / 2 + 10;
        const maxTop = viewportHeight - elementHeight / 2 - 10;

        initialLeft = Math.max(minLeft, Math.min(initialLeft, maxLeft));
        initialTop = Math.max(minTop, Math.min(initialTop, maxTop));
        
        textElement.style.left = `${initialLeft}px`;
        textElement.style.top = `${initialTop}px`;
        textElement.style.transform = `translate(-50%, -50%)`; // 居中對齊計算點
        
    } else { // +N 數字提示：保持在圖片上方居中
        textElement.textContent = `+${clickCount}`; // 恢復顯示累計點擊數
        const baseFontSize = 24; 
        const randomFontSize = baseFontSize + Math.floor(Math.random() * 8); 
        textElement.style.fontSize = `${randomFontSize}px`;
        const randomColor = `hsl(${Math.random() * 360}, 100%, 70%)`; 
        textElement.style.color = randomColor;

        textElement.style.left = `${rect.left + img.offsetWidth / 2}px`;
        textElement.style.top = `${rect.top - 40}px`; 
        textElement.style.transform = `translate(-50%, 0)`; 
    }
    
    document.body.appendChild(textElement); // 將元素添加到 DOM
    
    // 判斷飄浮距離和方向
    let floatDirectionX = 0;
    let floatDirectionY = 0;
    let fadeOutDuration = PLUS_N_MESSAGE_FADE_DURATION; // +N 數字的預設淡出時間

    if (isHundredMultiple) {
        floatDirectionX = -100; 
        fadeOutDuration = HUNDRED_CLICK_MESSAGE_FADE_DURATION;
    } else if (isTeasingMessage) {
        floatDirectionX = Math.random() * 20 - 10; 
        floatDirectionY = Math.random() * 20 - 10; 
        fadeOutDuration = TEASING_MESSAGE_FADE_DURATION;
    } else { 
        floatDirectionY = -60; 
    }

    requestAnimationFrame(() => { 
        textElement.style.opacity = '1';
        if (isHundredMultiple) {
            textElement.style.transform = `translate(calc(-100% + ${floatDirectionX}px), -50%)`; 
        } else if (isTeasingMessage) {
            textElement.style.transform = `translate(calc(-50% + ${floatDirectionX}px), calc(-50% + ${floatDirectionY}px))`; 
        }
        else { // +N 數字
            textElement.style.transform = `translate(-50%, ${floatDirectionY}px)`;
        }
        textElement.style.transition = `opacity ${fadeOutDuration / 1000}s ease-out, transform ${fadeOutDuration / 1000}s ease-out`;
    });

    // 定時將元素移除
    setTimeout(() => {
        textElement.style.opacity = '0'; // 先讓它淡出
        // 延遲一點點移除，確保過渡完成
        setTimeout(() => {
             textElement.remove(); 
        }, 200); // 這裡的 200ms 是為了確保淡出動畫完成
       
    }, fadeOutDuration);
}

// --- 動態注入點擊計數動畫和中心訊息的 CSS 樣式 ---
// 這個函數現在只用於確保一個基本的樣式ID存在，實際的樣式已移至 showClickTextOrMessage 函數中
function addClickCountAnimationStyles() {
    const styleId = 'character-click-count-styles';
    if (document.getElementById(styleId)) {
        return;
    }
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = `
        /* 由於關鍵樣式已移至行內，這裡只保留非常基礎的確保樣式層次 */
        /* .floating-message-dynamic 類名已在 showClickTextOrMessage 內部處理 */
    `;
    document.head.appendChild(style);
}

// --- 模式啟動/停止的輔助函數 ---
function stopAllModeBehaviors() {
    // 移除所有可能的 document 級別的滑鼠監聽器
    document.removeEventListener('mousemove', mouseMoveListener);
    document.removeEventListener('mouseup', onMouseUpHomeMode); 

    // 移除所有可能的 img 元素級別的滑鼠監聽器
    img.removeEventListener('mousedown', onMouseDownHomeMode); 
    if (imgClickListener) { 
        img.removeEventListener('click', imgClickListener);
        imgClickListener = null; 
    }

    // 清除所有動畫和計時器
    if (followAnimationFrameId) {
        cancelAnimationFrame(followAnimationFrameId);
        followAnimationFrameId = null;
    }
    if (playModeInterval) {
        clearInterval(playModeInterval);
        playModeInterval = null;
    }
    if (stationaryBounceTimer) {
        clearTimeout(stationaryBounceTimer);
        stationaryBounceTimer = null;
    }
    if (stationaryBounceInterval) {
        clearInterval(stationaryBounceInterval);
        stationaryBounceInterval = null;
    }
    isStationaryBouncing = false;
    isClickAnimating = false;
    isDragging = false; // 重置拖曳狀態
    isEscaping = false; // [新增] 重置逃跑狀態

    // 重置累計放大狀態
    currentAccumulatedScale = 1.0; 
    currentScaleLevel = 0;
    if (resetAccumulatedScaleTimer) {
        clearTimeout(resetAccumulatedScaleTimer);
        resetAccumulatedScaleTimer = null;
    }

    // 重置基礎圖片樣式
    img.style.pointerEvents = 'none'; // 預設禁用
    img.style.transition = 'left 0.3s ease-out, top 0.3s ease-out, transform 0.3s ease-out, opacity 0.3s ease-in-out';
    img.style.animation = 'none'; 
    img.style.transform = 'none'; 
    img.style.right = ''; // 清除 right/bottom
    img.style.bottom = '';
}

function startHomeMode() {
    // console.log('啟動顧家模式'); // 優化：移除頻繁日誌，此處保留
    img.style.position = 'fixed';
    img.style.transition = 'none'; // 顧家模式本身不需要移動過渡，只在點擊時有 transform 過渡
    img.style.pointerEvents = 'auto'; // 啟用點擊和拖曳

    // 從儲存中讀取顧家模式的上次位置
    chrome.storage.local.get(HOME_POSITION_STORAGE_KEY, (data) => {
        let storedPos = data[HOME_POSITION_STORAGE_KEY];
        let targetLeft, targetTop;

        const currentImgWidth = img.offsetWidth || originalImgWidth;
        const currentImgHeight = img.offsetHeight || (originalImgWidth * (img.naturalHeight / img.naturalWidth || 1));

        if (storedPos && typeof storedPos.left === 'number' && typeof storedPos.top === 'number') {
            targetLeft = storedPos.left;
            targetTop = storedPos.top;
        } else {
            // 如果沒有儲存位置，則預設在右下角
            targetLeft = window.innerWidth - currentImgWidth - 15;
            targetTop = window.innerHeight - currentImgHeight - 15;
        }
        // 設定圖片位置
        img.style.left = targetLeft + 'px';
        img.style.top = targetTop + 'px';
    });

    // 綁定顧家模式特有的事件監聽器
    img.addEventListener('mousedown', onMouseDownHomeMode);
    
    // 恢復顧家模式的靜止彈跳 Interval
    stationaryBounceInterval = setInterval(() => {
        triggerStationaryBounce();
    }, Math.random() * 2000 + 3000);
}

function startFollowMode() {
    // console.log('啟動跟隨模式'); // 優化：移除頻繁日誌，此處保留
    img.style.position = 'fixed';
    img.style.transition = `left ${FOLLOW_TRANSITION_DURATION}s ease-out, top ${FOLLOW_TRANSITION_DURATION}s ease-out`;
    img.style.pointerEvents = 'auto'; // 啟用點擊

    // 初始化 currentX, currentY 為圖片當前中心位置，確保從屏幕中心開始
    const currentImgWidth = img.offsetWidth || originalImgWidth;
    const currentImgHeight = img.offsetHeight || (originalImgWidth * (img.naturalHeight / img.naturalWidth || 1));
    currentX = (window.innerWidth / 2) - (currentImgWidth / 2);
    currentY = (window.innerHeight / 2) - (currentImgHeight / 2);
    img.style.left = currentX + 'px';
    img.style.top = currentY + 'px';

    const mouseIdleDuration = 1000;
    const resetStationaryBounceTimer = () => {
        if (stationaryBounceTimer) {
            clearTimeout(stationaryBounceTimer);
        }
        if (isStationaryBouncing) {
            img.style.transform = 'none';
            isStationaryBouncing = false;
        }
        if (!isClickAnimating) {
            stationaryBounceTimer = setTimeout(() => {
                triggerStationaryBounce();
            }, mouseIdleDuration);
        }
    };

    // 綁定 document 的 mousemove 監聽器
    mouseMoveListener = (e) => {
        targetX = e.clientX + currentFollowDistance;
        targetY = e.clientY + currentFollowDistance;

        currentX += (targetX - currentX) * 0.12;
        currentY += (targetY - currentY) * 0.12;

        img.style.left = currentX + 'px';
        img.style.top = currentY + 'px';

        resetStationaryBounceTimer();
    };
    document.addEventListener('mousemove', mouseMoveListener);
    resetStationaryBounceTimer();

    // 綁定跟隨模式的點擊監聽器
    imgClickListener = () => {
        triggerClickBounceAndEnlarge();
    };
    img.addEventListener('click', imgClickListener);
}

// [新增函數] 遊玩模式點擊後快速滑動逃跑動畫
function triggerPlayModeEscape() {
    if (!img || isEscaping || isBouncing) return; // 避免重複觸發或與其他遊玩模式動作衝突

    isEscaping = true;
    
    // 計算新的逃跑目標位置
    const currentLeft = parseFloat(img.style.left);
    const currentTop = parseFloat(img.style.top);
    
    const escapeDistance = 150; // 逃跑距離
    const randomAngle = Math.random() * 2 * Math.PI; // 隨機方向
    
    const targetX = currentLeft + escapeDistance * Math.cos(randomAngle);
    const targetY = currentTop + escapeDistance * Math.sin(randomAngle);

    // 限制逃跑範圍在視窗內
    const imgWidth = img.offsetWidth;
    const imgHeight = img.offsetHeight;
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    const clampedTargetX = Math.max(-imgWidth * 0.2, Math.min(targetX, viewportWidth - imgWidth * 0.8));
    const clampedTargetY = Math.max(-imgHeight * 0.2, Math.min(targetY, viewportHeight - imgHeight * 0.8));

    // 應用逃跑動畫
    img.style.transition = `left ${PLAY_MODE_ESCAPE_DURATION / 1000}s ease-out, top ${PLAY_MODE_ESCAPE_DURATION / 1000}s ease-out, transform ${PLAY_MODE_ESCAPE_DURATION / 1000}s ease-out`;
    img.style.transform = 'scale(0.8)'; // 稍微縮小，看起來像快速移動
    img.style.left = `${clampedTargetX}px`;
    img.style.top = `${clampedTargetY}px`;

    setTimeout(() => {
        img.style.transform = 'scale(1)'; // 恢復大小
        isEscaping = false;
        // 恢復正常的遊玩模式過渡
        img.style.transition = 'left 1.5s ease-out, top 1.5s ease-out, transform 0.6s ease-out, opacity 0.3s ease-in-out';
    }, PLAY_MODE_ESCAPE_DURATION);
}


function startPlayMode() {
    // console.log('啟動遊玩模式'); // 優化：移除頻繁日誌，此處保留
    img.style.position = 'fixed';
    img.style.transition = 'left 1.5s ease-out, top 1.5s ease-out, transform 0.6s ease-out, opacity 0.3s ease-in-out';
    img.style.pointerEvents = 'auto'; // 啟用點擊

    // 遊玩模式初始位置設定為頁面中心
    const currentImgWidth = img.offsetWidth || originalImgWidth;
    const currentImgHeight = img.offsetHeight || (originalImgWidth * (img.naturalHeight / img.naturalWidth || 1));
    img.style.left = (window.innerWidth / 2) - (currentImgWidth / 2) + 'px';
    img.style.top = (window.innerHeight / 2) - (currentImgHeight / 2) + 'px';

    const getRandomPlayTargetCoordinate = (viewportDim, imgDim) => {
        const overlapPercent = 0.10;
        const minCoord = -imgDim * overlapPercent;
        const maxCoord = viewportDim - imgDim + (imgDim * overlapPercent);
        
        const edgeRange = Math.min(viewportDim * 0.15, 100);
        let targetCoord;

        if (Math.random() < 0.7) {
            if (Math.random() < 0.5) {
                targetCoord = Math.random() * edgeRange + minCoord;
            } else {
                targetCoord = viewportDim - imgDim - Math.random() * edgeRange + (imgDim * overlapPercent);
            }
        } else {
            targetCoord = Math.random() * (viewportDim - imgDim - 2 * edgeRange) + edgeRange;
        }

        targetCoord = Math.max(minCoord, Math.min(targetCoord, maxCoord));
        return targetCoord;
    };

    const triggerPlayfulAction = () => {
        if (isBouncing || isClickAnimating || isEscaping) return; // [修改] 增加 isEscaping 判斷

        const actionType = Math.random();
        const currentLeft = parseFloat(img.style.left);
        const currentTop = parseFloat(img.style.top);

        isBouncing = true;
        img.style.transition = 'left 0.3s ease-out, top 0.3s ease-out, transform 0.3s ease-out, opacity 0.3s ease-in-out';

        if (actionType < 0.4) {
            img.style.top = `${currentTop - img.offsetHeight * 0.8}px`;
            setTimeout(() => {
                img.style.top = `${currentTop}px`;
                setTimeout(() => {
                    img.style.transition = 'left 1.5s ease-out, top 1.5s ease-out, transform 0.6s ease-out, opacity 0.3s ease-in-out';
                    isBouncing = false;
                }, 300);
            }, 300);
        } else if (actionType < 0.7) {
            const rotateDeg = Math.random() > 0.5 ? 360 : -360;
            img.style.transform = `rotate(${rotateDeg}deg) scale(0.9)`;
            setTimeout(() => {
                img.style.transform = 'none';
                setTimeout(() => {
                    img.style.transition = 'left 1.5s ease-out, top 1.5s ease-out, transform 0.6s ease-out, opacity 0.3s ease-in-out';
                    isBouncing = false;
                }, 600);
            }, 600);
        } else {
            img.style.opacity = '0';
            img.style.left = `${currentLeft + (Math.random() * 50 - 25)}px`;
            img.style.top = `${currentTop + (Math.random() * 50 - 25)}px`;
            setTimeout(() => {
                img.style.opacity = '1';
                img.style.left = `${currentLeft}px`;
                img.style.top = `${currentTop}px`;
                setTimeout(() => {
                    img.style.transition = 'left 1.5s ease-out, top 1.5s ease-out, transform 0.6s ease-out, opacity 0.3s ease-in-out';
                    isBouncing = false;
                }, 300);
            }, 500);
        }
    };

    const setRandomPlayTarget = () => {
        if (isBouncing || isClickAnimating || isEscaping) return; // [修改] 增加 isEscaping 判斷

        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        const imgWidth = img.offsetWidth;
        const imgHeight = img.offsetHeight;

        const targetX = getRandomPlayTargetCoordinate(viewportWidth, imgWidth);
        const targetY = getRandomPlayTargetCoordinate(viewportHeight, imgHeight);

        img.style.left = targetX + 'px';
        img.style.top = targetY + 'px';
        // console.log(`遊玩模式移動到: left(${targetX}px), top(${targetY}px)`); // 優化：移除頻繁日誌

        if (Math.random() < PLAY_MODE_ACTION_CHANCE) {
            triggerPlayfulAction();
        }
    };

    setRandomPlayTarget();

    playModeInterval = setInterval(() => {
        setRandomPlayTarget();
    }, Math.random() * (PLAY_MODE_INTERVAL_MAX - PLAY_MODE_INTERVAL_MIN) + PLAY_MODE_INTERVAL_MIN);
    // console.log('啟動遊玩模式 Interval'); // 優化：移除頻繁日誌，此處保留
    
    // 綁定遊玩模式的點擊監聽器
    imgClickListener = () => {
        // [修改] 先觸發對話，再觸發逃跑動畫
        const msg = teasingMessages[Math.floor(Math.random() * teasingMessages.length)];
        showClickTextOrMessage(false, msg, true);
        triggerPlayModeEscape(); // [新增] 觸發逃跑動畫
        // console.log(`遊玩模式角色被點擊，說: "${msg}"`); // 優化：移除頻繁日誌
    };
    img.addEventListener('click', imgClickListener);
}


// --- 模式切換邏輯 ---
function changeMode(newMode) {
    console.log('--- 嘗試切換模式到:', newMode, '---'); // 優化：保留模式切換的重要日誌
    mode = newMode;

    if (chrome && chrome.storage && chrome.storage.local) { 
        chrome.storage.local.set({ mode: mode }, () => {
            // console.log('模式已儲存到 storage:', mode); // 優化：移除頻繁日誌
        });
    } else {
        console.warn("chrome.storage.local 不可用，無法儲存模式設定。"); // 優化：保留警告日誌
    }

    ensureFollowerImg(); 

    if (!img) {
        console.error("無法切換模式：角色圖片元素未成功創建。"); // 優化：保留錯誤日誌
        return;
    }

    // 1. 清理所有舊模式的行為
    stopAllModeBehaviors();

    // 2. 啟動新模式的行為 (短暫延遲，讓樣式過渡生效)
    setTimeout(() => {
        // 確保圖片可見
        img.style.opacity = '1';
        img.style.display = 'block';
        img.style.zIndex = '999999';

        switch (newMode) {
            case 'home':
                startHomeMode();
                break;
            case 'follow':
                startFollowMode();
                break;
            case 'play':
                startPlayMode();
                break;
            default:
                console.error('未知模式:', newMode); // 優化：保留錯誤日誌
                startHomeMode(); // 預設回到顧家模式
        }

        // 如果角色被隱藏，則強制隱藏
        if (isHidden) {
            img.style.display = 'none';
            // console.log('角色因 isHidden 為 true 而隱藏'); // 優化：移除頻繁日誌
        } else {
            // console.log('角色已顯示'); // 優化：移除頻繁日誌
        }
    }, 50); // 短暫延遲，讓基礎樣式重置和通用過渡生效
}


// --- 顧家模式拖曳事件處理函數 ---
function onMouseDownHomeMode(e) {
    // 確保只處理圖片本身的 mousedown 事件，而不是其子元素（如文字動畫）
    if (e.button !== 0 || e.target !== img) return; 

    // 記錄點擊時的滑鼠位置
    lastMouseDownX = e.clientX;
    lastMouseDownY = e.clientY;

    // 記錄圖片當前位置與滑鼠點擊點的偏移量
    const rect = img.getBoundingClientRect();
    dragOffsetX = e.clientX - rect.left;
    dragOffsetY = e.clientY - rect.top;

    isDragging = false; // 初始設為非拖曳狀態

    // 暫時移除顧家模式的靜止彈跳，避免拖曳時彈跳
    if (stationaryBounceInterval) {
        clearInterval(stationaryBounceInterval);
        stationaryBounceInterval = null;
    }
    if (stationaryBounceTimer) {
        clearTimeout(stationaryBounceTimer);
        stationaryBounceTimer = null;
    }
    isStationaryBouncing = false;

    // 暫時移除圖片的過渡效果，使拖曳更流暢
    img.style.transition = 'none';

    // 綁定全局的 mousemove 和 mouseup，確保即使滑鼠移出圖片區域也能正常拖曳和釋放
    document.addEventListener('mousemove', onMouseMoveHomeMode);
    document.addEventListener('mouseup', onMouseUpHomeMode);

    // 阻止默認拖曳行為（例如圖片拖曳到新標籤頁）
    e.preventDefault(); 
}

function onMouseMoveHomeMode(e) {
    // 判斷是否超過拖曳門檻，如果沒有且是第一次移動，則開始拖曳
    if (!isDragging && (Math.abs(e.clientX - lastMouseDownX) > DRAG_THRESHOLD || Math.abs(e.clientY - lastMouseDownY) > DRAG_THRESHOLD)) {
        isDragging = true;
        // 如果開始拖曳，則清除所有累計放大相關的計時器和變換
        currentAccumulatedScale = 1.0;
        currentScaleLevel = 0;
        if (resetAccumulatedScaleTimer) {
            clearTimeout(resetAccumulatedScaleTimer);
            resetAccumulatedScaleTimer = null;
        }
        img.style.transform = 'none';
    }

    if (isDragging) {
        let newX = e.clientX - dragOffsetX;
        let newY = e.clientY - dragOffsetY;

        // 限制拖曳範圍在可視視窗內
        newX = Math.max(0, Math.min(newX, window.innerWidth - img.offsetWidth));
        newY = Math.max(0, Math.min(newY, window.innerHeight - img.offsetHeight));

        img.style.left = newX + 'px';
        img.style.top = newY + 'px';
        img.style.right = ''; // 拖曳時清除 right/bottom
        img.style.bottom = '';
    }
}

function onMouseUpHomeMode(e) {
    // 移除事件監聽器，無論是拖曳還是點擊，鼠標抬起後都應該停止監聽這些事件
    document.removeEventListener('mousemove', onMouseMoveHomeMode);
    document.removeEventListener('mouseup', onMouseUpHomeMode);

    // 拖曳結束後，如果顧家模式的靜止彈跳被清除了，需要重新啟動它
    if (mode === 'home' && !stationaryBounceInterval) {
        stationaryBounceInterval = setInterval(() => {
            triggerStationaryBounce();
        }, Math.random() * 2000 + 3000);
    }

    if (isDragging) {
        isDragging = false; // 重置拖曳狀態
        // console.log(`顧家模式拖曳完成，位置：left=${img.style.left}, top=${img.style.top}`); // 優化：移除頻繁日誌
        // 儲存新的位置
        if (chrome && chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({ [HOME_POSITION_STORAGE_KEY]: { left: parseFloat(img.style.left), top: parseFloat(img.style.top) } });
        }
        // 拖曳結束後，圖片位置已經固定，不需要額外點擊
        // img.style.transition = ''; // 保持 none 或根據需要設置
    } else {
        // 如果不是拖曳 (即是點擊)，則觸發累計放大和數字動畫
        // 確保 e.target 是圖片本身，避免點到其他浮動元素 (例如文字動畫)
        if (e.target === img) { 
            handleAccumulatedScaleClick(); // 處理累計放大邏輯

            clickCount++;
            if (chrome && chrome.storage && chrome.storage.local) {
                chrome.storage.local.set({ [CLICK_COUNT_STORAGE_KEY]: clickCount });
            }
            
            if (clickCount > 0 && clickCount % 100 === 0 && clickCount !== lastEncouragementTriggerCount) { 
                lastEncouragementTriggerCount = clickCount; 
                const msg = reminderMessages[Math.floor(Math.random() * reminderMessages.length)]; 
                showClickTextOrMessage(true, msg); 
                // console.log(`觸發百次提示: ${msg} (點擊數: ${clickCount})`); // 優化：移除頻繁日誌
            } else {
                showClickTextOrMessage(false); // 顯示 +N 數字動畫
            }
            // console.log('角色被點擊，當前累計點擊數:', clickCount); // 優化：移除頻繁日誌
        }
    }
}

// --- 訊息處理邏輯 ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // 在處理任何訊息之前，先確保 img 元素存在
    ensureFollowerImg();

    if (message.type === 'updateSettings') {
        updateCharacterSettings(
            message.identifier,
            Number(message.width) || 64,
            Number(message.followDistance) || 35,
            message.hidden, 
            message.clickCount, 
            () => {
                sendResponse({ status: 'ok' });
            }
        );
        return true;
    }

    if (message.type === 'hideImage') {
        isHidden = true;
        if (img) img.style.display = 'none';
        if (chrome && chrome.storage && chrome.storage.local) { 
            chrome.storage.local.set({ hidden: true });
        } else {
            console.warn("chrome.storage.local 不可用，無法儲存隱藏狀態。"); // 優化：保留警告日誌
        }
        sendResponse({ status: 'ok' });
        return true;
    }

    if (message.type === 'showImage') {
        isHidden = false;
        if (img) img.style.display = 'block';
        if (chrome && chrome.storage && chrome.storage.local) { 
            chrome.storage.local.set({ hidden: false });
        } else {
            console.warn("chrome.storage.local 不可用，無法儲存顯示狀態。"); // 優化：保留警告日誌
        }
        sendResponse({ status: 'ok' });
        return true;
    }

    if (message.type === 'changeMode') {
        changeMode(message.mode);
        sendResponse({ status: 'mode changed' });
        return true;
    }

    sendResponse({ status: 'unknown message type' });
    return false;
});

// --- 初始載入設定 ---
function initializeCharacter() {
    console.log('初始化角色功能開始...'); // 優化：保留重要的啟動日誌
    // 確保 img 元素在讀取設置前就嘗試創建
    ensureFollowerImg(); 

    new Promise(resolve => {
        if (chrome && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(['selectedCharacter', 'selectedWidth', 'selectedFollowDistance', 'customCharacters', 'mode', 'hidden', CLICK_COUNT_STORAGE_KEY, HOME_POSITION_STORAGE_KEY], (localData) => { 
                resolve(localData);
            });
        } else {
            console.warn("chrome.storage.local 不可用，使用預設設定初始化。"); // 優化：保留警告日誌
            resolve({ 
                selectedCharacter: 'builtin-0',
                selectedWidth: 64,
                selectedFollowDistance: 35,
                customCharacters: [],
                mode: 'follow', // 將這裡的預設模式設置為您希望的初始模式
                hidden: false,
                [CLICK_COUNT_STORAGE_KEY]: 0,
                [HOME_POSITION_STORAGE_KEY]: null // 預設沒有儲存位置
            });
        }
    }).then((localData) => { 
        // console.log('所有儲存資料或預設值已載入。準備更新圖片並應用模式。', localData); // 優化：移除，因為下面的詳細日誌已足夠
        
        const customs = localData.customCharacters || [];

        const selected = (customs.length > 0 && localData.selectedCharacter === 'custom') ? 'custom' : (localData.selectedCharacter && localData.selectedCharacter.startsWith('builtin-') ? localData.selectedCharacter : 'builtin-0');
        const width = localData.selectedWidth || 64;
        const followDistance = localData.selectedFollowDistance || 35;

        // 確保 content script 的預設模式與 popup 一致，或從 storage 讀取
        const storedMode = localData.mode || 'follow'; // 這裡的預設值也應該與 Promise 中的 mode 一致
        // console.log('從儲存中讀取到的模式:', localData.mode, '將使用的模式:', storedMode); // 優化：移除，除非真的很關鍵
        const initialHiddenState = localData.hidden || false; 
        
        // 確保 clickCount 總是從儲存中正確讀取或初始化為0
        // 使用 || 0 確保如果 storage 中沒有，則為 0
        clickCount = localData[CLICK_COUNT_STORAGE_KEY] || 0; 
        // console.log('初始化載入計數:', clickCount); // 優化：移除
        lastEncouragementTriggerCount = Math.floor(clickCount / 100) * 100;

        isHidden = initialHiddenState;

        updateCharacterSettings(selected, width, followDistance, initialHiddenState, clickCount, () => { 
            // console.log('圖片載入完成，應用儲存的模式。'); // 優化：移除
            changeMode(storedMode);
        });
    }).catch(error => {
        console.error('初始化過程中發生錯誤:', error); // 優化：保留錯誤日誌
    });
}

// MutationObserver 相關邏輯
let observer = null;
let initAttempted = false; // 追蹤是否已經嘗試過初始化

function startMonitoringBody() {
    if (observer) observer.disconnect();

    // 延遲以確保 body 元素存在
    // 增加一個最長重試次數，避免無限循環
    let retryCount = 0;
    const maxRetries = 10;
    const checkBody = () => {
        const body = document.body;
        if (!body) {
            console.warn(`Body 元素尚不存在，無法開始監控。(重試 ${retryCount + 1}/${maxRetries})`); // 優化：保留警告日誌
            if (retryCount < maxRetries) {
                retryCount++;
                setTimeout(checkBody, 500); // 如果 body 不存在，則稍後重試
            } else {
                console.error('無法找到 body 元素，放棄監控。'); // 優化：保留錯誤日誌
            }
            return;
        }

        observer = new MutationObserver((mutations) => {
            let characterRemoved = false;
            for (let mutation of mutations) {
                if (mutation.type === 'childList' && mutation.removedNodes.length > 0) {
                    for (let node of mutation.removedNodes) {
                        // 檢查被移除的節點是否是圖片元素本身，或者整個 body 被替換
                        if (node === img || (node.nodeName === 'BODY' && node.nodeType === 1)) {
                            characterRemoved = true;
                            break;
                        }
                    }
                }
                if (characterRemoved) break; // 找到後即可跳出循環
            }

            if (characterRemoved) {
                console.warn('角色圖片元素或整個 DOM 被從 DOM 移除！嘗試重新初始化。'); // 優化：保留警告日誌
                // 清理所有計時器和監聽器
                stopAllModeBehaviors();
                
                // 重新初始化，但設定一個小的延遲，避免頻繁的 DOM 操作
                setTimeout(() => {
                    initializeCharacter();
                }, 100); 
            }
        });

        observer.observe(body, { childList: true, subtree: true });
        // console.log('MutationObserver 已啟動監控 body 變化。'); // 優化：移除頻繁日誌

        if (!initAttempted) {
            initializeCharacter();
            initAttempted = true;
        }
    };

    checkBody(); // 開始檢查 body 元素
}

document.addEventListener('DOMContentLoaded', () => {
    addClickCountAnimationStyles(); 

    window.addEventListener('beforeprint', () => {
        if (img) {
            originalDisplayState = img.style.display; // 儲存當前顯示狀態
            img.style.display = 'none';
            // console.log('beforeprint: 角色圖片已隱藏。'); // 優化：移除頻繁日誌
        }
    });

    window.addEventListener('afterprint', () => {
        if (img) {
            // 打印結束後恢復原始顯示狀態，但如果 isHidden 還是 true 則保持隱藏
            img.style.display = isHidden ? 'none' : originalDisplayState;
            // console.log('afterprint: 角色圖片已恢復。'); // 優化：移除頻繁日誌
        }
    });

    startMonitoringBody();
});

window.addEventListener('load', () => {
    // console.log('Window Load 觸發，確保角色存在。'); // 優化：移除頻繁日誌
    // 在 window load 時再次檢查並初始化，以應對一些特殊頁面載入情況
    if (!img || !document.body.contains(img)) {
        initializeCharacter();
    }
});