// popup.js - 最終修正版，精確同步 clickCount

function debounce(func, wait) {
  let timeout;
  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

document.addEventListener('DOMContentLoaded', () => {
  const characterSelect = document.getElementById('character');
  const previewImg = document.getElementById('preview');
  const widthRange = document.getElementById('widthRange');
  const widthLabel = document.getElementById('widthLabel');
  const followDistanceRange = document.getElementById('followDistanceRange');
  const followDistanceLabel = document.getElementById('followDistanceLabel');
  const uploadInput = document.getElementById('upload');
  const clearCustomBtn = document.getElementById('clearCustom');
  const followBtn = document.getElementById('followBtn');
  const homeBtn = document.getElementById('homeBtn');
  const playBtn = document.getElementById('playBtn');
  const toggleVisibilityBtn = document.getElementById('toggleVisibility');

  let currentMode = 'home';
  let currentCharacter = 'builtin-0';
  let currentWidth = 64;
  let currentFollowDistance = 35;
  let isCharacterHidden = false;
  let currentClickCount = 0;

  // [修正] 統一 builtinCharacters 陣列的 value 命名為 builtin-X 格式，並確保所有都有 path
  const builtinCharacters = [
    { name: '吉伊卡哇', value: 'builtin-0', path: 'images/chiikawa_001.gif' },
    { name: '小八貓', value: 'builtin-1', path: 'images/hachiware_001.gif' },
    { name: '烏薩奇', value: 'builtin-2', path: 'images/usagi_001.gif' },
    { name: '卡娜赫拉', value: 'builtin-3', path: 'images/Kanahei.gif' },
    { name: '線條小狗1', value: 'builtin-4', path: 'images/maltese.gif' },
    { name: '線條小狗2', value: 'builtin-5', path: 'images/maltese2.gif' }, // [修正] 添加 path 屬性並統一 value
    { name: '史努比', value: 'builtin-6', path: 'images/snoopy.gif' },
    { name: 'Hello Kitty', value: 'builtin-7', path: 'images/hellokitty.gif' }
  ];

  const maxWidth = 320;
  widthRange.min = 32;
  widthRange.max = maxWidth;
  widthRange.step = 4;

  const maxFollowDistance = 100;
  const minFollowDistance = 0;
  const stepFollowDistance = 5;
  followDistanceRange.min = minFollowDistance;
  followDistanceRange.max = maxFollowDistance;
  followDistanceRange.step = stepFollowDistance;

  // --- 發送訊息到 Content Script (延遲發送以避免頻繁更新) ---
  let debounceTimer;
  function sendUpdateDebounced() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      sendMessageToContentScript('updateSettings', {
        identifier: currentCharacter,
        width: currentWidth,
        followDistance: currentFollowDistance,
        hidden: isCharacterHidden,
        clickCount: currentClickCount
      });
    }, 100);
  }

  // --- 通用訊息發送函數 (增加重試和錯誤提示) ---
  function sendMessageToContentScript(type, payload = {}, retries = 3, delay = 200) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length === 0) {
        console.warn("沒有活躍的標籤頁可以發送訊息。請確保您在一個網頁上打開擴充功能。");
        alert("請在一個網頁上打開擴充功能，或重新整理頁面後再試。"); // 提供用戶提示
        return;
      }
      
      const tabId = tabs[0].id;
      
      const attemptSendMessage = (currentRetry) => {
        chrome.tabs.sendMessage(tabId, { type: type, ...payload }, (response) => {
          if (chrome.runtime.lastError) {
            const errorMessage = chrome.runtime.lastError.message;
            console.warn(`訊息發送失敗 (嘗試 ${currentRetry}/${retries} 次):`, errorMessage);
            if (currentRetry < retries && errorMessage.includes('Receiving end does not exist')) {
              // 如果 Content Script 還未準備好，等待一段時間後重試
              setTimeout(() => attemptSendMessage(currentRetry + 1), delay);
            } else {
              console.error("訊息發送最終失敗或 Content Script 未響應:", errorMessage);
              // 可以在這裡給出更友好的用戶提示
              if (errorMessage.includes('Receiving end does not exist')) {
                 alert("角色服務尚未準備好或頁面加載中，請稍後再試或刷新頁面。");
              } else {
                 alert("與角色服務通訊失敗，請重新整理頁面。");
              }
            }
          } else {
            console.log("訊息響應:", response);
          }
        });
      };

      attemptSendMessage(1); // 開始第一次嘗試
    });
  }

  // --- 更新選單選項 ---
  function populateSelect(customs) {
    characterSelect.innerHTML = '';
    builtinCharacters.forEach(char => {
      const option = document.createElement('option');
      option.value = char.value;
      option.textContent = char.name;
      characterSelect.appendChild(option);
    });

    if (customs && customs.length > 0) {
      const customOption = document.createElement('option');
      customOption.value = 'custom';
      customOption.textContent = '自訂角色';
      characterSelect.appendChild(customOption);
    }
  }

  // --- 載入設定並初始化 UI ---
  function loadSettings() {
    chrome.storage.local.get(['selectedCharacter', 'selectedWidth', 'selectedFollowDistance', 'customCharacters', 'mode', 'hidden', 'characterClickCount'], (localData) => {
      const customs = localData.customCharacters || [];
        
      populateSelect(customs);

      // [修正] 確保 currentCharacter 始終與實際可用的選項匹配
      let resolvedCharacter = localData.selectedCharacter;
      if (resolvedCharacter === 'custom' && (!customs || customs.length === 0)) {
          resolvedCharacter = 'builtin-0'; 
      } else if (!resolvedCharacter || !builtinCharacters.some(c => c.value === resolvedCharacter) && resolvedCharacter !== 'custom') {
          // 如果儲存的值不存在於內建列表，且不是有效的自訂選項，則預設為 builtin-0
          resolvedCharacter = 'builtin-0';
      }
      currentCharacter = resolvedCharacter;
      
      currentWidth = localData.selectedWidth || 64;
      currentFollowDistance = localData.selectedFollowDistance || 35;
      currentMode = localData.mode || 'home'; // 保持與 content.js 的預設同步
      isCharacterHidden = localData.hidden || false;
      currentClickCount = localData.characterClickCount || 0;

      characterSelect.value = currentCharacter; 
      widthRange.value = currentWidth;
      widthLabel.textContent = currentWidth;
      followDistanceRange.value = currentFollowDistance;
      followDistanceLabel.textContent = currentFollowDistance;

      updatePreview(currentCharacter);
      updateToggleButton();
      updateModeButtons();

      sendUpdateDebounced(); // 確保 content script 收到最新設定
    });
  }

  // --- 更新預覽圖片 ---
  function updatePreview(identifier) {
    let srcToDisplay;
    if (identifier === 'custom') {
      chrome.storage.local.get('customCharacters', (data) => {
        const customs = data.customCharacters || [];
        srcToDisplay = customs.length > 0 ? customs[0].value : chrome.runtime.getURL(builtinCharacters[0].path);
        previewImg.src = srcToDisplay;
      });
    } else {
      // [修正] 確保找到正確的內建角色物件，並使用其 path
      const char = builtinCharacters.find(b => b.value === identifier);
      srcToDisplay = char ? chrome.runtime.getURL(char.path) : chrome.runtime.getURL(builtinCharacters[0].path);
      previewImg.src = srcToDisplay;
    }
  }

  // --- 更新模式按鈕狀態 ---
  function updateModeButtons() {
    [followBtn, homeBtn, playBtn].forEach(btn => {
      btn.style.backgroundColor = ''; 
      btn.style.color = '';
    });

    if (currentMode === 'follow') {
      followBtn.style.backgroundColor = '#81d4fa';
      followBtn.style.color = 'white';
    } else if (currentMode === 'home') {
      homeBtn.style.backgroundColor = '#a5d6a7';
      homeBtn.style.color = 'white';
    } else if (currentMode === 'play') {
      playBtn.style.backgroundColor = '#ffcc80';
      playBtn.style.color = 'white'; 
    }
  }

  // --- 更新隱藏/顯示按鈕文字 ---
  function updateToggleButton() {
    toggleVisibilityBtn.textContent = isCharacterHidden ? '顯示角色' : '暫時隱藏角色';
    toggleVisibilityBtn.style.backgroundColor = isCharacterHidden ? '#f44336' : '#3f51b5';
    toggleVisibilityBtn.style.color = 'white';
  }

  // --- 事件監聽器 ---

  // 角色選擇
  characterSelect.addEventListener('change', (event) => {
    currentCharacter = event.target.value;
    updatePreview(currentCharacter);
    chrome.storage.local.set({ selectedCharacter: currentCharacter }, () => {
      sendUpdateDebounced();
    });
  });

  // 寬度調整
  widthRange.addEventListener('input', (event) => {
    currentWidth = Number(event.target.value);
    widthLabel.textContent = currentWidth;
    chrome.storage.local.set({ selectedWidth: currentWidth }, () => {
      sendUpdateDebounced();
    });
  });

  // 跟隨距離調整
  followDistanceRange.addEventListener('input', (event) => {
    currentFollowDistance = Number(event.target.value);
    followDistanceLabel.textContent = currentFollowDistance;
    chrome.storage.local.set({ selectedFollowDistance: currentFollowDistance }, () => {
      sendUpdateDebounced();
    });
  });

  // 上傳自訂圖片
  uploadInput.addEventListener('change', (event) => {
    const file = event.target.files[0];
    const MAX_FILE_SIZE_KB = 500;
    const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_KB * 1024;

    if (!file) {
      return;
    }

    if (file.size > MAX_FILE_SIZE_BYTES) {
      alert(`檔案大小超過限制！請選擇小於 ${MAX_FILE_SIZE_KB} KB 的圖片。當前檔案大小：${(file.size / 1024).toFixed(2)} KB`);
      uploadInput.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const imgDataUrl = e.target.result;
      chrome.storage.local.set({ customCharacters: [{ name: 'custom', value: imgDataUrl }] }, () => {
        console.log('Custom character saved to local storage.');
        
        // **核心修改：模擬手動選擇 '自訂角色' 的動作**
        // 1. 確保 '自訂角色' 選項已經在下拉選單中
        populateSelect([{ name: 'custom', value: imgDataUrl }]); 
        
        // 2. 延遲執行，給瀏覽器足夠時間處理 DOM 更新
        requestAnimationFrame(() => {
            setTimeout(() => {
                characterSelect.value = 'custom'; // 強制設定選單值
                currentCharacter = 'custom'; // 更新內部狀態變數
                updatePreview(currentCharacter); // 更新預覽圖片
                sendUpdateDebounced(); // 發送更新訊息到 content script
                
                // 模擬觸發 change 事件，確保所有相關監聽器都被觸發
                characterSelect.dispatchEvent(new Event('change')); 
                console.log("上傳後，已自動模擬選擇 '自訂角色'。");
            }, 50); // 50ms 延遲，給予瀏覽器 DOM 渲染時間
        });

      });
    };
    reader.readAsDataURL(file);
  });

  // 清除自訂圖片
  clearCustomBtn.addEventListener('click', () => {
    if (confirm('確定要清除所有自訂圖片嗎？')) {
      chrome.storage.local.remove('customCharacters', () => {
        console.log('Custom character cleared from local storage.');
        // 清除後重新填充選單，確保 'custom' 選項被移除
        populateSelect([]); 

        // [修正] 清除自訂圖片後，將選單值設定回 'builtin-0'
        characterSelect.value = 'builtin-0'; 
        currentCharacter = 'builtin-0';
        updatePreview(currentCharacter);
        sendUpdateDebounced();
      });
    }
  });

  // 模式按鈕
  followBtn.addEventListener('click', () => {
    currentMode = 'follow';
    updateModeButtons();
    chrome.storage.local.set({ mode: currentMode }, () => {
        sendMessageToContentScript('changeMode', { mode: currentMode });
    });
  });

  homeBtn.addEventListener('click', () => {
    currentMode = 'home';
    updateModeButtons();
    chrome.storage.local.set({ mode: currentMode }, () => {
        sendMessageToContentScript('changeMode', { mode: currentMode });
    });
  });

  playBtn.addEventListener('click', () => {
    currentMode = 'play';
    updateModeButtons();
    chrome.storage.local.set({ mode: currentMode }, () => {
        sendMessageToContentScript('changeMode', { mode: currentMode });
    });
  });

  // 隱藏/顯示按鈕
  toggleVisibilityBtn.addEventListener('click', () => {
    isCharacterHidden = !isCharacterHidden;
    updateToggleButton();
    const messageType = isCharacterHidden ? 'hideImage' : 'showImage';
    chrome.storage.local.set({ hidden: isCharacterHidden }, () => {
        sendMessageToContentScript(messageType);
    });
  });

  // 初始載入設定
  loadSettings();
});